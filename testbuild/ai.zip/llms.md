# hl7.fhir.no.hackathon.2026#0.2.5: Norwegian FHIR Hackathon 2026

## Pages

* [](index.md)
* [IHE documents](ihe-track.md)
* [EHDS track](ehds-track.md)
* [Resultater Pmd](resultater-pmd.md)
* [Hackathon agenda](hack-agenda.md)
* [Pre-agenda](pre-agenda.md)
* [Artifacts Summary](artifacts.md)
* [Resultater Okt](resultater-okt.md)
* [Medication Definition](medication-definition.md)
* [Track Descriptions](track-descriptions.md)
* [Terminology](terminology.md)
* [2026 Changes](2026-changes.md)
* [Pictures from 2025](2025-bilder.md)
* [Practical Info](practical-info.md)
* [SMART on FHIR](smart-track.md)
* [Ig Publishing Results](ig-publishing-results.md)
* [NHN services](nhn-track.md)
* [FHIR-101](101-track.md)

## Resources

### Resource Profiles

* [Blodprøve](StructureDefinition-mal-observation-blodprove.md)
* [Pasient](StructureDefinition-mal-patient.md)

### ImplementationGuides

* [Norwegian FHIR Hackathon 2026](index.md)

### Examples

* [Pasient-1 (Patient)](Patient-Pasient-1.md)
