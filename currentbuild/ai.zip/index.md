# Norwegian FHIR Hackathon 2026 - Norwegian FHIR Hackathon 2026 v1.0.1

* [**Table of Contents**](toc.md)
* **Norwegian FHIR Hackathon 2026**

## Norwegian FHIR Hackathon 2026

| | |
| :--- | :--- |
| *Official URL*:http://hl7.no/fhir/ig/hackathon/2026/ImplementationGuide/hl7.fhir.no.hackathon.2026 | *Version*:1.0.1 |
| Draft as of 2026-06-26 | *Computable Name*:NorwegianFHIRHackathon2026 |

Are you ready to make the interoperability solutions of the future? Participate on The Norwegin FHIR Hackathon 2026, a part of [EHiN](https://ehin.no/) pre-conference. The Norwegian FHIR Hackathon is an arena for creativity, networking and innovation, with HL7 FHIR front and centre.

The Norwegian FHIR Hackathon 2026 takes place at Rebel in Oslo 9. november 2026. The Norwegian FHIR hackathon is hosted by [HL7 Norge](https://www.hl7.no/) in cooperation with [NHN](https://www.nhn.no/), [Helsedirektoratet](https://www.helsedirektoratet.no/), [Bedredelt](https://bedredelt.no/), [NoMA](https://www.dmp.no/en/), IHE Norge and [EHiN](https://ehin.no/).

This hackathon is part of the [Nordic Health Data Hackathons](https://fhir.fi/hackathon/) series.

### Tracks

The Norwegian Hackathon will have 6 tracks concerning municipality services, SMART on FHIR, FHIR 101, Document sharing, medication databases, and EHDS.

* [NHN FHIR services track, particularly CarePlans and Observations](nhn-track.md) - NHN, Robert William Dall Frøseth
* [Medication Definition on FHIR - Exploration of FHIR services from NoMA and EMA](medication-definition.md)
* [Document sharing for IHE MHD](ihe-track.md) - IHE Norge, Ingvar Sørlien
* [EHDS track](ehds-track.md) - Ingvar Sørlien
* [SMART on FHIR](smart-track.md) - NAV, Leo-Andreas Ervik
* [FHIR 101: Introduction to HL7 FHIR with practical assignments](101-track.md) - HL7 Norge, Thomas Rosenlund og Espen Seland
* Option: C-3po - Proxy for FHIR API access to data from national health portals

### Why should you attend?

The main goals of the Norwegian FHIR Hackathon is to build FHIR competence in the Norwegian e-health community by implementing and testing actual FHIR RESTful API's and software. The Norwegian FHIR Hackathon is a typical learning-by-doing event where you can expect to build, write and test things yourself. The Norwegian FHIR Hackathon is also a great place to discuss problems and find solutions in cooperation with the other participants.

During the Norwegian FHIR Hackathon you can work on:

* CarePlan
* Observation
* Document sharing
* EHDS compliance
* SMART on FHIR
* IG authoring and building

> DISCLAIMER: The results from the FHIR Hackaton signifies no obligation from the API owner (e.g. NHN/NAV), to make changes to their published API-services or software.

### Who should attend?

The event will be of value to individuals working in the healthcare industry and software providers in healthcare.

* Developers
* Solution architects
* Information architects
* Enterprise architects
* Project managers

### Preparations for participants

**Attend the pre meeting on 2. november 2026 0900-1100 (digital only)**

* Basic knowledge of RESTful API's is usefull to be able to participate in testing and development
* Knowledge of at least one of the following areas: 
* Development of RESTful API clients/servers
* Information modelling
* Testing RESTful APIs
* Using RESTful APIs using Postman
* Use of AI tools for development
 
* Some basic knowledge of the HL7 FHIR standard is valuable, but no prerequisite (intro to FHIR will be provided in the FHIR 101 track). HL7 also provides some great video resources for this purpose: 
* [FHIR 101](https://vimeo.com/1102006982/68c2e4fcfb)
* [How to read an implementation guide](https://vimeo.com/1102008456/cc0e9cddbd)
* [Newcomer orientation](https://vimeo.com/542197402/8fb80fea04)
 

### Hackathon events for 2026

The Norwegian FHIR Hackathon is a part of a Norwegian initiative to host [Health Data Hackathons](https://fhir.fi/hackathon/) in each Nordic country each year. Please consider attendance on the other Nordic hackathons as well.

### Questions and contact

Please contact [Thomas Tveit Rosenlund](mailto:thomas.tveit.rosenlund@helsedir.no) if you got any questions regarding the event.

