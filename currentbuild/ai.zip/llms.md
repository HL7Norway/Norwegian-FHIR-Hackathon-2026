# hl7.fhir.no.hackathon.2026#1.4.9: Norwegian FHIR Hackathon 2026

## Pages

* [](index.md)
* [Pre-agenda](pre-agenda.md)
* [Artifacts Summary](artifacts.md)
* [Pictures from 2025](2025-bilder.md)
* [IHE documents](ihe-track.md)
* [NHN services](nhn-track.md)
* [Privacy Information](privacy.md)
* [Hackathon agenda](hack-agenda.md)
* [FHIR-101](101-track.md)
* [EHDS track](ehds-track.md)
* [Medication Definition](medication-definition.md)
* [SMART on FHIR](smart-track.md)

## Resources

### Resource Profiles

* [Blodprøve](StructureDefinition-mal-observation-blodprove.md)
* [Pasient](StructureDefinition-mal-patient.md)

### ImplementationGuides

* [Norwegian FHIR Hackathon 2026](index.md)

### Examples

* [Pasient-1 (Patient)](Patient-Pasient-1.md)
