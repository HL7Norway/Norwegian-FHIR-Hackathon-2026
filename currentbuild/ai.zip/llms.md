# hl7.fhir.no.hackathon.2026#1.0.3: Norwegian FHIR Hackathon 2026

## Pages

* [](index.md)
* [IHE documents](ihe-track.md)
* [EHDS track](ehds-track.md)
* [Hackathon agenda](hack-agenda.md)
* [Artifacts Summary](artifacts.md)
* [Medication Definition](medication-definition.md)
* [Pictures from 2025](2025-bilder.md)
* [SMART on FHIR](smart-track.md)
* [NHN services](nhn-track.md)
* [FHIR-101](101-track.md)

## Resources

### Resource Profiles

* [Blodprøve](StructureDefinition-mal-observation-blodprove.md)
* [Pasient](StructureDefinition-mal-patient.md)

### ImplementationGuides

* [Norwegian FHIR Hackathon 2026](index.md)

### Examples

* [Pasient-1 (Patient)](Patient-Pasient-1.md)
