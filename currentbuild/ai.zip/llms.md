# hl7.fhir.no.hackathon.2026#1.5.0: Norwegian FHIR Hackathon 2026

## Pages

* [](index.md)
* [Resultater fra 2026](results.md)
* [FHIR-101](101-track.md)
* [NHN services](nhn-track.md)
* [Artifacts Summary](artifacts.md)
* [Privacy Information](privacy.md)
* [Medication Definition](medication-definition.md)
* [Pre-agenda](pre-agenda.md)
* [IHE documents](ihe-track.md)
* [Pictures from 2025](2025-bilder.md)
* [EHDS track](ehds-track.md)
* [SMART on FHIR](smart-track.md)
* [Hackathon agenda](hack-agenda.md)

## Resources

### Resource Profiles

* [Blodprøve](StructureDefinition-mal-observation-blodprove.md)
* [Pasient](StructureDefinition-mal-patient.md)

### ImplementationGuides

* [Norwegian FHIR Hackathon 2026](index.md)

### Examples

* [Pasient-1 (Patient)](Patient-Pasient-1.md)
