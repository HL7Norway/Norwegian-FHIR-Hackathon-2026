# hl7.fhir.no.hackathon.2026#0.1.0: Norwegian FHIR Hackathon 2026

## Pages

* [Home](index.md)
* [Practical Info](practical-info.md)
* [Track Descriptions](track-descriptions.md)
* [Nhn Track](nhn-track.md)
* [Artifacts Summary](artifacts.md)
* [Resultater Okt](resultater-okt.md)
* [Ig Publishing Results](ig-publishing-results.md)
* [Terminology](terminology.md)
* [101 Track](101-track.md)
* [Resultater Pmd](resultater-pmd.md)
* [2026 Changes](2026-changes.md)
* [Ihe Track](ihe-track.md)
* [Hack Agenda](hack-agenda.md)
* [Pre Agenda](pre-agenda.md)
* [Smart Track](smart-track.md)
* [Ehds Track](ehds-track.md)

## Resources

### Resource Profiles

* [Blodprøve](StructureDefinition-mal-observation-blodprove.md)
* [Pasient](StructureDefinition-mal-patient.md)

### ImplementationGuides

* [Norwegian FHIR Hackathon 2026](index.md)

### Examples

* [Pasient-1 (Patient)](Patient-Pasient-1.md)
