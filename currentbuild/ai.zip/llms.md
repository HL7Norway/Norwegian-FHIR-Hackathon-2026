# hl7.fhir.no.hackathon.2026#1.4.8: Norwegian FHIR Hackathon 2026

## Pages

* [](index.md)
* [Artifacts Summary](artifacts.md)
* [SMART on FHIR](smart-track.md)
* [EHDS track](ehds-track.md)
* [Privacy Information](privacy.md)
* [Pre-agenda](pre-agenda.md)
* [Hackathon agenda](hack-agenda.md)
* [FHIR-101](101-track.md)
* [IHE documents](ihe-track.md)
* [NHN services](nhn-track.md)
* [Pictures from 2025](2025-bilder.md)
* [Medication Definition](medication-definition.md)

## Resources

### Resource Profiles

* [Blodprøve](StructureDefinition-mal-observation-blodprove.md)
* [Pasient](StructureDefinition-mal-patient.md)

### ImplementationGuides

* [Norwegian FHIR Hackathon 2026](index.md)

### Examples

* [Pasient-1 (Patient)](Patient-Pasient-1.md)
