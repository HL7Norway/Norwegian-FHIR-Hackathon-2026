# hl7.fhir.no.hackathon.2026#0.1.1: Norwegian FHIR Hackathon 2026

## Pages

* [Home](index.md)
* [Smart Track](smart-track.md)
* [Resultater Okt](resultater-okt.md)
* [101 Track](101-track.md)
* [Nhn Track](nhn-track.md)
* [Artifacts Summary](artifacts.md)
* [Practical Info](practical-info.md)
* [Ihe Track](ihe-track.md)
* [Terminology](terminology.md)
* [Ehds Track](ehds-track.md)
* [Track Descriptions](track-descriptions.md)
* [Ig Publishing Results](ig-publishing-results.md)
* [Pre Agenda](pre-agenda.md)
* [Resultater Pmd](resultater-pmd.md)
* [Hack Agenda](hack-agenda.md)
* [2026 Changes](2026-changes.md)

## Resources

### Resource Profiles

* [Blodprøve](StructureDefinition-mal-observation-blodprove.md)
* [Pasient](StructureDefinition-mal-patient.md)

### ImplementationGuides

* [Norwegian FHIR Hackathon 2026](index.md)

### Examples

* [Pasient-1 (Patient)](Patient-Pasient-1.md)
