# hl7.fhir.no.hackathon.2026#1.4.2: Norwegian FHIR Hackathon 2026

## Pages

* [](index.md)
* [Medication Definition](medication-definition.md)
* [Artifacts Summary](artifacts.md)
* [SMART on FHIR](smart-track.md)
* [FHIR-101](101-track.md)
* [IHE documents](ihe-track.md)
* [EHDS track](ehds-track.md)
* [NHN services](nhn-track.md)
* [Pictures from 2025](2025-bilder.md)
* [Privacy Information](privacy.md)
* [Hackathon agenda](hack-agenda.md)

## Resources

### Resource Profiles

* [Blodprøve](StructureDefinition-mal-observation-blodprove.md)
* [Pasient](StructureDefinition-mal-patient.md)

### ImplementationGuides

* [Norwegian FHIR Hackathon 2026](index.md)

### Examples

* [Pasient-1 (Patient)](Patient-Pasient-1.md)
