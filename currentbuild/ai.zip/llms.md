# hl7.fhir.no.hackathon.2026#0.0.2: Norwegian FHIR Hackathon 2026

## Pages

* [Home](index.md)
* [Track Descriptions](track-descriptions.md)
* [Terminology](terminology.md)
* [Hack Agenda](hack-agenda.md)
* [Resultater Pmd](resultater-pmd.md)
* [Resultater Okt](resultater-okt.md)
* [2026 Changes](2026-changes.md)
* [Pre Agenda](pre-agenda.md)
* [Artifacts Summary](artifacts.md)
* [Ig Publishing](ig-publishing.md)
* [Practical Info](practical-info.md)
* [Ig Publishing Results](ig-publishing-results.md)

## Resources

### Resource Profiles

* [Blodprøve](StructureDefinition-mal-observation-blodprove.md)
* [Pasient](StructureDefinition-mal-patient.md)

### ImplementationGuides

* [Norwegian FHIR Hackathon 2026](index.md)

### Examples

* [Pasient-1 (Patient)](Patient-Pasient-1.md)
