# Nhn Track - Norwegian FHIR Hackathon 2026 v0.2.4

* [**Table of Contents**](toc.md)
* **Nhn Track**

## Nhn Track

### NHN Track

#### Prerequisites and preparations

##### Preparations

The presentations from the pre-meetings contain information about the FHIR IG authoring track included links to tools, introductory guides and specifications that are usefull to prepare for the Hackathon.

**Coming**

#### Learning goals

#### Use-cases and assignments

