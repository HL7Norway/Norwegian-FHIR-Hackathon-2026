# SMART on FHIR - Norwegian FHIR Hackathon 2026 v1.5.0

* [**Table of Contents**](toc.md)
* **SMART on FHIR**

## SMART on FHIR

### SMART on FHIR Track

> FHIR is the data. SMART is what makes an app safe to plug into someone else's journal system. In this track you build the plug.

Track lead: Leo-Andreas Ervik, Nav.

Co-host: Jørn-Are Klubben Flaten, Nav.

### Start here

1. Your group is the table you sit at, 4 to 6 people.
1. Create your team's repository from the[starter](https://github.com/navikt/smart-on-fhir-templates)and follow its`public/README.md`.
1. Open[nav-epj](https://epj.ekstern.dev.nav.no/). On the HelseID login page, choose**TestIDP**, manually enter the**fødselsnummer**(personal identifier) of a Syntpop test clinician from your group below, and log in.
1. Open the browser checklist. It marks the 10 TODOs as you finish them, and explains why each one matters.

**Syntpop test clinicians**

Each group shares its six test clinicians. Use a clinician from your group's rows below. Enter all 11 digits of the fødselsnummer, including any leading zero. These are synthetic test identities.

| | | |
| :--- | :--- | :--- |
| 1 | `28677509882` | LØSNINGSORIENTERT DIAMETER |
| 1 | `22728131350` | BESTEMT FOTNOTE |
| 1 | `21687739091` | GØYAL FATTET DUE |
| 1 | `27717523763` | RETT BYTTE |
| 1 | `12775015754` | FORSKJELLIG JOURNAL |
| 1 | `25725696917` | PASSIV RAVGUL OPPVASKMASKIN |
| 2 | `04685611959` | KOMPATIBEL MÅNE |
| 2 | `05687536179` | INKONSEKVENT KORTSTOKK |
| 2 | `06676340007` | RETT DEKLARASJON |
| 2 | `08695717505` | UKJENT LITEN AGG |
| 2 | `04667408313` | ÄNDLÖS VOTT |
| 2 | `06705502321` | OPPFARENDE FABRIKKPIPE |
| 3 | `13747390929` | COMÚN LIGGESTOL |
| 3 | `03726112907` | VÅKEN EVALUERING |
| 3 | `08775501708` | FINTFØLENDE SLAPP FARESKILT |
| 3 | `25687490072` | PÅLITELIG TREGRENSE |
| 3 | `17707948426` | UROLIG HUSBÅT |
| 3 | `22667416691` | RASTLØS BIOGRAF |
| 4 | `20716600700` | TREIG HEST |
| 4 | `10697019362` | VARSOM TUNFISK |
| 4 | `15765612710` | KUNSTIG ONSDAG |
| 4 | `12675904675` | ARITMETISK NØYTRAL FJELLKJEDE |
| 4 | `23736428482` | HANDLENDE AKADEMISK BOOM |
| 4 | `06745732826` | PRODUKTIV SVALE |
| 5 | `31666735709` | JUSTERBAR FASE |
| 5 | `28695936569` | TRIST TROMMIS |
| 5 | `30745547741` | UGJENNOMSIKTIG BIOLOGI |
| 5 | `08685422981` | UMAKE FUNKSJONÆR |
| 5 | `25727599404` | VARSOM SERVITUTT |
| 5 | `20665046924` | OPPSTEMT FLØYTE |

### Table of Contents

* [Start here](#start-here)
* [What this track is about](#what-this-track-is-about)
* [Terms and abbreviations](#terms-and-abbreviations)
* [What the track provides](#what-the-track-provides)
* [About the skeleton](#about-the-skeleton)
* [Prerequisites](#prerequisites)
* [Learning goals](#learning-goals)
* [Use-cases and assignments](#use-cases-and-assignments)
* [Bronze](#bronze)
* [Silver](#silver)
* [Gold](#gold)
* [Team roles](#team-roles)
* [Practical](#practical)
* [Reference material](#reference-material)
* [Questions](#questions)

### What this track is about

Most of us know FHIR as "resources and a REST API". Far fewer have worked with the SMART half of SMART on FHIR and how an application is launched from inside an EPJ, how it learns which patient, which clinician and which consultation without anyone typing anything. And how the EPJ stays in control of what that application is allowed to see.

By the end of the day you will have built a working SMART application and launched it from an EPJ provided by the track, against synthetic Norwegian patients.

No prior SMART or FHIR experience is needed. Teams mix developers and low-code or no-code builders, see [Team roles](#team-roles).

### Terms and abbreviations

The track mixes Norwegian and international terminology, because the specifications are written in English while the systems and identifiers we work with are Norwegian. This is the vocabulary we use.

**Systems and standards**

| | |
| :--- | :--- |
| EPJ | Elektronisk pasientjournal. The clinical system that holds the record and launches your app. This page uses EPJ throughout. |
| EHR | Electronic Health Record. The international term for the same thing. The SMART specification calls the flow we use**EHR launch**, so you will meet "EHR" in the spec where we say "EPJ". |
| FHIR | HL7's standard for exchanging health data. The data model and the REST API. |
| SMART | The standard that lets an EPJ launch a third-party app, authenticate the user, and hand the app a limited, short-lived access token. |
| SMART on FHIR | The two combined. SMART handles who you are and what you may see, FHIR handles the data itself. |
| HelseID | The national identity provider for Norwegian health personnel. |
| IG | Implementation Guide. A published specification such as this page's parent document. |

**SMART and OAuth vocabulary**

| | |
| :--- | :--- |
| Launch | The EPJ opening your app, passing along a one-time`launch`identifier. |
| Launch context | What the app is told about the situation: which patient, which encounter, which user. |
| Scope | The permissions the app asks for, for example`patient/Condition.read`. A contract between app and EPJ. |
| Access token | The short-lived credential the app uses when calling the FHIR API. |
| ID-token | Tells the app who the logged-in user is. |
| PKCE | Proof Key for Code Exchange. Stops someone else from stealing and using your authorization code. |
| Discovery | Reading`.well-known/smart-configuration`to learn where the EPJ's endpoints are. |
| JWKS | The public keys used to verify that a token really came from who it claims. |

**Norwegian identifiers and code systems**

| | |
| :--- | :--- |
| Fødselsnummer | The 11-digit Norwegian national identity number. |
| D-nummer | Identity number for people without a fødselsnummer, such as short-term residents. |
| HPR-nummer | The identifier for registered health personnel. Identifies the clinician. |
| Organisasjonsnummer | The identifier for a legal entity, such as a fastlegekontor. |
| ICPC-2 | Diagnosis coding used in Norwegian primary care. |
| ICD-10 | Diagnosis coding used in specialist care. |
| LOINC | International coding for measurements and lab results. |

### What the track provides

* [**nav-epj**](https://epj.ekstern.dev.nav.no/), an EPJ with its own SMART authorization server and a FHIR R4 API. This is the system that launches your application.
* **Synthetic Norwegian patient data**: patients with fødselsnummer and d-nummer, clinicians with HPR-nummer, organisations with organisasjonsnummer, consultations, diagnoses coded with ICPC-2 and ICD-10, and measurements.
* A **starter repository** with a `public/` exercise containing numbered `TODO`s and finished templates in `client-secret/`, `private-key-jwt/` and `backend-services/`.
* **Credentials** on the day: the shared public `client_id` (`hackathon-public`), a set of test clinicians per group, and a list of patients. Mentors register secret or key clients on request.
* A browser checklist that tells you what to fix, why it matters, and what to try when you are stuck.
* Mentors circulating throughout the day.

### About the skeleton

The `public/` skeleton implements the SMART launch from scratch, server-side. It does not use an off-the-shelf SMART client library, for two reasons:

1. You learn more by making the discovery request, generating the PKCE verifier, validating the token and extracting the launch context yourself than by calling`authorize()`.
1. A token held in the browser can be read by any script running on the page. The skeleton keeps tokens on the server and shows you how.

A reference implementation is provided for when you get stuck.

### Prerequisites

No prior SMART or FHIR knowledge is required, and there is no required pre-work. Turn up and we will get you running. If FHIR itself is new to you, consider dropping into the [FHIR 101 track](101-track.md) in the morning.

What you need on the day:

| | |
| :--- | :--- |
| A laptop | Any operating system. You will be writing and running code on it. |
| A code editor | Visual Studio Code, IntelliJ IDEA or whichever you already use. Either is fine. |
| A GitHub account | You will clone the starter repository and push your team's work. |
| Node 22 | For running the starter locally. |
| A charger | ⚡️ |

Optional, only if SMART is entirely new to you, and you want a head start:

* [SMART App Launch Implementation Guide](https://hl7.org/fhir/smart-app-launch/), skim "App Launch" and "Scopes and Launch Context".
* [FHIR 101](https://vimeo.com/1102006982/68c2e4fcfb) and [Newcomer orientation](https://vimeo.com/542197402/8fb80fea04).

### Learning goals

By the end of the day you should be able to:

* explain in one sentence why SMART exists, and what problem it solves for a clinician;
* describe the launch sequence, and say what each of `iss`, `launch`, `state`, `code_verifier`, `aud` and `code` is protecting against;
* read a `.well-known/smart-configuration` document and know which endpoints matter;
* explain scopes as a contract between the app and the EPJ, and inspect a token to see what was actually granted;
* explain why access tokens belong on the server and not in the browser;
* name the three SMART client authentication types, and say which one a Norwegian EPJ vendor should be using today;
* describe how HelseID relates to, and differs from, the EPJ's own SMART authorization server.

### Use-cases and assignments

After the shared intro there is no presenter and no scheduled checkpoint. Learn SMART, then build, using the browser checklist (why, hints and rescue for each TODO), the discussion prompts in the starter README and the pacing rule below. Mentors help when you get stuck.

Assignments come in three tiers. Pick the one that matches your team and move up during the day. This is a learning track, not a competition. There are no prizes, and helping the team next to you is encouraged.

Your team chooses the clinical workflow it builds for. You can take one of the optional [problem cards](https://github.com/navikt/smart-on-fhir-templates/blob/main/public/EXERCISES.md#problem-cards), which are starting hypotheses rather than confirmed clinical needs, or bring your own idea.

### Bronze

**It launched.** Target: every team, before lunch.

Launch the skeleton from the EPJ, complete the authorization code exchange on the server, and display the patient's name and age together with the active consultation. The skeleton has 10 numbered TODOs and the checklist tracks them.

When all 10 are done, the checklist shows a "Before you build" box with discussion prompts. Answer them out loud to each other: open your browser's network tab and explain each redirect, and say what `iss`, `launch`, `state`, `code_verifier`, `aud` and `code` protect against. The prompts help you explain the flow. They do not make your app certified or secure.

If you are stuck, follow the [Stuck section](https://github.com/navikt/smart-on-fhir-templates/blob/main/public/README.md#stuck) of the starter README. Start with the hint and the why on the checklist, then compare your code with the solved step on GitHub, or run the full solved app in a separate folder.

* **Experienced with SMART?** Skip Bronze and start from the solved public app. It may not show the checklist, so work through the static [Before you build](https://github.com/navikt/smart-on-fhir-templates/blob/main/public/README.md#before-you-build) prompts in the README instead.
* **Not through Bronze before lunch?** Switch to the solved app and build after lunch. See [skip Bronze and pacing](https://github.com/navikt/smart-on-fhir-templates/blob/main/public/README.md#skip-bronze-and-pacing).

### Silver

**It is useful, and it is honest.** Pick one.

* **Clinical mini-app**: read the patient's diagnoses and measurements and render something a clinician would actually glance at. A trend, a summary, a flag. Use your chosen workflow or a problem card.
* **Scope detective**: request narrower scopes than the skeleton does. Decode the access token and the ID-token. Prove what you were granted versus what you asked for, and demonstrate the FHIR API refusing a request outside your scopes.

### Gold

**It writes back, or it does something nobody expected.**

Write-back is the default goal for the build phase; authentication options are optional extensions.

* **Write-back** (default): create a document or a measurement in the EPJ from your application, and watch it appear in the journal. The EPJ accepts specific shapes, listed under [write-back shapes](https://github.com/navikt/smart-on-fhir-templates/blob/main/public/EXERCISES.md#write-back-shapes).
* **Asymmetric client authentication**: implement `private_key_jwt` end to end. Ask a mentor to register a client.
* **Backend services**: a system-to-system SMART flow, with no user present at all. Ask a mentor to register a client.
* **Break it**: attack your own application. Tamper with `state`. Replay a `code`. Send a token with the wrong `aud`. Use an expired token. Ask for a resource outside your scopes. Document what the server correctly rejected, and what it did not.

### Team roles

Roles are for people who build in different ways, whether they write code or use low-code and no-code tools. Every team member can contribute without writing the OAuth flow by hand. Swap roles during the day. Several people can share a role.

* **Navigator**: reads the hints and the why-text aloud, keeps the checklist, and asks the discussion prompts.
* **Problem owner**: owns the clinical question for your chosen workflow or problem card, and decides what the clinician needs to see or save.
* **Break-it tester**: attacks the app and the EPJ with `curl` and the browser, as described under Break it in [Gold](#gold), and keeps notes on what was rejected.
* **UI/demo builder**: builds the screens, preferably in the solved app's pages, and prepares the README and screenshot.

### Practical

* **Language**: the track is facilitated in Norwegian. All written material, code and documentation is in English, with Norwegian terms kept where they are the actual names of things. See [Terms and abbreviations](#terms-and-abbreviations).
* **AI tools**: GitHub Copilot, Claude, Cursor and similar are welcome. They are good at OAuth boilerplate and at reading HTTP error responses. They know very little about HelseID and Norwegian code systems, and will confidently invent both.
* **Organization**: about 5 groups of 4 to 6 people, one group per table.
* **Results**: each team publishes a repository with a short README and a screenshot. The track lead picks a few short demos to show in the shared plenary, so not every team will get a demo slot.

### Reference material

* [SMART App Launch IG (STU 2.2)](https://hl7.org/fhir/smart-app-launch/)
* [Scopes and launch context](https://hl7.org/fhir/smart-app-launch/scopes-and-launch-context.html)
* [Conformance and `.well-known/smart-configuration`](https://hl7.org/fhir/smart-app-launch/conformance.html)
* [SMART App Launcher](https://launch.smarthealthit.org), public sandbox used as fallback environment
* [navikt/smart-on-fhir-templates](https://github.com/navikt/smart-on-fhir-templates), starter exercise and finished templates
* [navikt/smart-on-fhir](https://github.com/navikt/smart-on-fhir), Nav's server-only SMART on FHIR library
* [navikt/smart-on-fhir-validator](https://github.com/navikt/smart-on-fhir-validator), validates a SMART/FHIR implementation against Nav's requirements
* [HL7 FHIR R4 resource list](https://hl7.org/fhir/R4/resourcelist.html)
* [OID-identifikatorserier i helse- og omsorgstjenesten](https://www.helsedirektoratet.no/digitalisering-og-e-helse/e-helsestandarder-og-standardiseringstiltak/oid-identifikatorserier-i-helse-og-omsorgstjenesten), the authoritative list of Norwegian identifier series

### Questions

Contact the track lead, [Leo-Andreas Ervik (Nav)](mailto:leo-andreas.ervik@nav.no), or ask in the track channel.

